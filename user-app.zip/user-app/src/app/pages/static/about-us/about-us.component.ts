import { Component } from '@angular/core';

@Component({
  selector: 'app-about-us',
  template: '<div>About US Page</div>',
})
export class AboutUsComponent {}
