import { Component } from '@angular/core';

@Component({
  selector: 'app-contact',
  template: '<div>Contact US Page</div>',
})
export class ContactComponent {}
